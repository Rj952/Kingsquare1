// This file runs on the SERVER only — your API key is never sent to the browser.
// It receives the food photo from the app, sends it to Claude, and returns the analysis.

export async function POST(request) {
  try {
    const { image, mediaType } = await request.json();

    if (!image) {
      return Response.json(
        { error: "No image provided" },
        { status: 400 }
      );
    }

    // Your Anthropic API key is stored safely in Vercel's Environment Variables
    const apiKey = process.env.ANTHROPIC_API_KEY;

    if (!apiKey) {
      return Response.json(
        { error: "API key not configured. See README for setup instructions." },
        { status: 500 }
      );
    }

    const response = await fetch("https://api.anthropic.com/v1/messages", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "x-api-key": apiKey,
        "anthropic-version": "2023-06-01",
      },
      body: JSON.stringify({
        model: "claude-sonnet-4-20250514",
        max_tokens: 1000,
        messages: [
          {
            role: "user",
            content: [
              {
                type: "image",
                source: {
                  type: "base64",
                  media_type: mediaType || "image/jpeg",
                  data: image,
                },
              },
              {
                type: "text",
                text: `You are a nutrition analyst for a health app targeting Black men over 50. Analyze this food image and respond ONLY with a JSON object (no markdown, no backticks, no preamble):
{
  "foods": [
    {
      "name": "Food name",
      "portion": "estimated portion size",
      "calories": number,
      "protein": number (grams),
      "carbs": number (grams),
      "fat": number (grams),
      "fiber": number (grams),
      "icon": "single emoji representing this food"
    }
  ],
  "total_calories": number,
  "total_protein": number,
  "total_carbs": number,
  "total_fat": number,
  "total_fiber": number,
  "health_tip": "One culturally relevant health tip about this meal for a Black man over 50, relating to heart health, blood pressure, or diabetes prevention. Keep it warm and encouraging.",
  "health_rating": "green" or "yellow" or "red",
  "rating_reason": "Brief explanation of the health rating"
}
If you see multiple food items on the plate, list each separately. Estimate portions based on visual appearance. Be accurate but conservative with calorie estimates. If the image is not food, set foods to empty array and total_calories to 0.`,
              },
            ],
          },
        ],
      }),
    });

    if (!response.ok) {
      const errorText = await response.text();
      console.error("Anthropic API error:", response.status, errorText);
      return Response.json(
        { error: `AI service error (${response.status})` },
        { status: 502 }
      );
    }

    const data = await response.json();
    const text = data.content?.map((b) => b.text || "").join("") || "";
    const cleaned = text.replace(/```json|```/g, "").trim();
    const parsed = JSON.parse(cleaned);

    return Response.json(parsed);
  } catch (error) {
    console.error("Scan error:", error);
    return Response.json(
      { error: "Failed to analyze food image. Please try again." },
      { status: 500 }
    );
  }
}
