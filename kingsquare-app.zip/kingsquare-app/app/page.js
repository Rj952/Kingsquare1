"use client";

import KingSquare from "../components/KingSquare";

export default function Home() {
  return <KingSquare />;
}
