# 👑 KingSquare — Wellness for Kings

### A wellness platform for Black men 50+ featuring health tracking, AI food scanning, culturally-specific meal planning, exercise programs, mental wellness tools, and community connection.

---

# 🚀 HOW TO PUT THIS LIVE ON THE INTERNET

## You Need 3 Free Accounts (5 minutes)

| Account | What It's For | Link |
|---------|--------------|------|
| **GitHub** | Stores your app's code (like Google Drive for code) | [github.com](https://github.com) |
| **Vercel** | Puts your app on the internet (free hosting) | [vercel.com](https://vercel.com) |
| **Anthropic** | Powers the AI food scanner | [console.anthropic.com](https://console.anthropic.com) |

---

## STEP 1: Create a GitHub Account (2 minutes)

1. Go to **[github.com](https://github.com)**
2. Click **"Sign up"**
3. Enter your email, create a password, choose a username
4. Verify your email
5. You're done — leave this tab open

---

## STEP 2: Upload This Project to GitHub (3 minutes)

1. On GitHub, click the **"+"** icon in the top-right corner
2. Click **"New repository"**
3. Name it: `kingsquare-app`
4. Make sure **"Public"** is selected
5. Check the box that says **"Add a README file"**
6. Click **"Create repository"**

Now upload the files:

7. On your new repository page, click **"Add file"** → **"Upload files"**
8. **Drag and drop the ENTIRE `kingsquare-app` folder** from your Downloads into the upload area
   - OR click "choose your files" and select all the files/folders inside the kingsquare-app folder
9. You should see these files and folders listed:
   ```
   app/
   components/
   public/
   .gitignore
   next.config.js
   package.json
   README.md
   ```
10. At the bottom, click **"Commit changes"**
11. Wait for it to upload — this takes about 30 seconds

> **Tip:** If GitHub shows a file called `README.md` that it created automatically, that's fine — your uploaded README.md will replace it.

---

## STEP 3: Deploy to Vercel (3 minutes)

1. Go to **[vercel.com](https://vercel.com)**
2. Click **"Sign Up"** → choose **"Continue with GitHub"**
3. Authorize Vercel to access your GitHub
4. Once logged in, click **"Add New..."** → **"Project"**
5. You'll see your `kingsquare-app` repository listed — click **"Import"**
6. Vercel will auto-detect that this is a Next.js project
7. **DON'T CHANGE ANY SETTINGS** — the defaults are correct
8. Click **"Deploy"**
9. Wait 1-2 minutes while it builds
10. 🎉 **You'll see a "Congratulations!" screen with a link to your live app!**

Your app is now live at something like: `kingsquare-app.vercel.app`

---

## STEP 4: Set Up the AI Food Scanner (3 minutes)

The food scanner needs an Anthropic API key to work. Without this step, everything else works — you just can't scan food photos.

1. Go to **[console.anthropic.com](https://console.anthropic.com)**
2. Sign up for an account
3. Go to **"API Keys"** in the left sidebar
4. Click **"Create Key"**
5. Name it `kingsquare`
6. **Copy the key** — it looks like: `sk-ant-api03-xxxxxxxxxxxx`

> ⚠️ **IMPORTANT:** You'll only see this key once. Copy it now.

Now add it to Vercel:

7. Go back to **[vercel.com](https://vercel.com)**
8. Click on your **kingsquare-app** project
9. Click **"Settings"** (tab at the top)
10. Click **"Environment Variables"** in the left sidebar
11. Add a new variable:
    - **Key:** `ANTHROPIC_API_KEY`
    - **Value:** Paste your API key (the `sk-ant-api03-xxxx...` thing)
    - Click **"Save"**
12. Go to the **"Deployments"** tab
13. Find your most recent deployment, click the **three dots (⋮)** → **"Redeploy"**
14. Wait 1-2 minutes

✅ **The AI food scanner now works!**

> **Cost note:** Anthropic gives you $5 in free credits to start. Each food scan costs about $0.01-0.02. That's roughly 250-500 free scans. After that, it's pay-as-you-go — very affordable.

---

## STEP 5: Get a Custom Domain Name (Optional)

Instead of `kingsquare-app.vercel.app`, you can use your own domain like `kingsquarewellness.com`.

1. Buy a domain from **[Namecheap](https://namecheap.com)** or **[Google Domains](https://domains.google)** (~$12/year)
2. In Vercel → Settings → Domains → Add your domain
3. Vercel will give you DNS settings to copy into your domain provider
4. Follow the on-screen instructions — Vercel walks you through it
5. Free SSL certificate is automatic (the padlock in the browser)

---

## STEP 6: Make It Installable on Phones (Already Done!)

Your app already has a PWA (Progressive Web App) manifest built in. This means:

### On iPhone:
1. Open your app in Safari
2. Tap the **Share button** (square with arrow)
3. Scroll down and tap **"Add to Home Screen"**
4. Tap **"Add"**
5. The KingSquare icon now appears on the home screen like a real app!

### On Android:
1. Open your app in Chrome
2. You'll see a banner: **"Add KingSquare to Home Screen"**
3. Tap **"Install"**
4. It appears on your home screen like a real app!

**No App Store needed. No Google Play needed. Free. Instant.**

---

## HOW TO CONNECT TO YOUR WIX SITE

If you want to link KingSquare from your existing Wix website:

### Option 1: Simple Link (Easiest)
Add a button on your Wix site that says "Launch KingSquare" and link it to:
```
https://kingsquare-app.vercel.app
```
(or your custom domain)

### Option 2: Embed Inside Wix
1. In Wix Editor, add an **"Embed Code"** element (under "Add" → "Embed Code" → "Embed HTML")
2. Paste this code:

```html
<iframe
  src="https://kingsquare-app.vercel.app"
  width="100%"
  height="900"
  style="border: none; border-radius: 16px; max-width: 480px; margin: 0 auto; display: block;"
  title="KingSquare Wellness App"
  allow="camera"
></iframe>
```

3. Adjust the height if needed
4. The app will appear directly inside your Wix page

> **Note:** The `allow="camera"` part is important — it lets the AI food scanner access the camera when embedded in Wix.

---

## HOW TO UPDATE THE APP LATER

Whenever you want to make changes:

1. Ask Claude to make the changes (like we've been doing)
2. Download the updated file(s)
3. Go to your GitHub repository
4. Click on the file you want to update
5. Click the **pencil icon** (Edit)
6. Replace the content with the new version
7. Click **"Commit changes"**
8. **Vercel automatically re-deploys** — your live site updates in ~1 minute!

Or, for bigger updates:
1. Ask Claude to generate the updated project
2. Upload the new files to GitHub (replacing the old ones)
3. Vercel auto-deploys

---

## WHAT EACH FILE DOES (In Plain English)

```
kingsquare-app/
│
├── app/                          ← The "behind the scenes" stuff
│   ├── layout.js                 ← Sets up fonts, title, PWA settings
│   ├── page.js                   ← The first page people see (loads the app)
│   ├── globals.css               ← Colors, scrollbars, animations
│   └── api/
│       └── scan-food/
│           └── route.js          ← Securely connects to Claude AI for food scanning
│
├── components/
│   └── KingSquare.jsx            ← THE ENTIRE APP — all 7 screens live here
│
├── public/                       ← Things the browser can access directly
│   ├── manifest.json             ← Tells phones "this can be installed as an app"
│   └── icons/
│       ├── icon-192.png          ← App icon (small)
│       └── icon-512.png          ← App icon (large)
│
├── package.json                  ← List of tools the app needs
├── next.config.js                ← Technical settings
├── .gitignore                    ← Tells GitHub to skip temporary files
└── README.md                     ← This file you're reading!
```

---

## TROUBLESHOOTING

### "Deploy Failed" on Vercel
- Make sure all files are uploaded correctly to GitHub
- Check that the folder structure matches what's shown above
- Try clicking "Redeploy" in Vercel

### Food Scanner Says "API key not configured"
- Go to Vercel → Settings → Environment Variables
- Make sure `ANTHROPIC_API_KEY` is set correctly
- Redeploy after adding the key

### Food Scanner Says "AI service error"
- Your Anthropic account may be out of credits
- Go to console.anthropic.com → Billing to check
- Add a payment method if needed ($5-20/month is typical)

### App Looks Wrong on My Phone
- Try clearing your browser cache
- Make sure you're using a modern browser (Safari 15+, Chrome 90+)

### I Want to Change Something in the App
- Just ask Claude! Share what you want changed and I'll update the code

---

## FUTURE ENHANCEMENTS (When You're Ready)

| Feature | What You'd Need | Difficulty |
|---------|----------------|-----------|
| User accounts & login | Supabase (free) or Clerk | Medium — ask Claude to set it up |
| Save health data permanently | Supabase database | Medium |
| Push notifications | Web Push API | Medium |
| Native mobile app | React Native conversion | Advanced |
| Community chat (real-time) | Supabase Realtime or Convex | Medium |
| Stripe payments for premium | Stripe + Vercel | Medium |

---

## BUILT WITH LOVE

KingSquare was designed with deep respect for the health needs, cultural traditions, and lived experiences of Black men over 50. Every feature — from the Kente cloth patterns to the soul food meal plans to the cerasee tea recommendations — was crafted to honor who you are while protecting your future.

**Wellness for Kings. 👑**

---

*Need help? Ask Claude to walk you through any step. I built this — I can fix it, update it, and extend it anytime.*
